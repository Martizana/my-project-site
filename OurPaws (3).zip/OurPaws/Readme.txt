Please find below the explanation and information on how the project requirements were completed:

### Plugins:
I used **Elementor Builder** to efficiently replicate the provided layout and design, ensuring the website is responsive, attractive, and functional. Additionally, I utilized an **Elementor Child Theme** to prevent any theme updates from affecting the customizations. The setup starts with a fresh, blank template, ideal for building a new website. I also incorporated custom CSS and PHP code to achieve the requested design.

### AJAX Form:
- **Step 1: Set Up the HTML Form**  
  I created a simple HTML form with fields for First Name, Last Name, Email, and Address. The form was added using an Elementor HTML widget.
  
- **Step 2: JavaScript & PHP Integration**  
  I added the JavaScript and PHP files into the theme's `functions.php` to ensure the AJAX functionality loads correctly.

### Banner Implementation (Requested):
- **Step 1: Add the Action Hook to Display the Banner**  
  I added the necessary code to `functions.php` to display the banner above the footer.
  
- **Step 2: Customizer Settings**  
  Additional code was added in `functions.php` to integrate the banner with the WordPress Customizer.
  
- **Step 3: Banner Styling**  
  I applied custom CSS in `style.css` for the banner’s design and layout.

- **Step 4: Testing the Customizer**  
  In the WordPress Dashboard, under Appearance → Customize, a new **"Promotional Banner"** section appears. Users can now add text in the "Banner Content" field and change the background color. Once saved, the banner will display just above the footer.

### Custom Post Type (CPT) for Services:
- **Step 1: Create the Custom Post Type**  
  I accessed the `functions.php` file (located in `wp-content/themes/your-child-theme/functions.php`) to create the CPT for "Dogs," which will manage services dynamically.

- **Step 2: Add CPT Code**  
  The custom post type code was added in `functions.php` to ensure the "Dogs" CPT functions correctly.

---

Let me know if you need any further Question!